-- cPanel mysql backup
GRANT USAGE ON *.* TO 'dftoldos'@'localhost' IDENTIFIED BY PASSWORD '*5A16A6FE169169B8C2825437C503942CEBB11205';
GRANT ALL PRIVILEGES ON `dftoldos\_%`.* TO 'dftoldos'@'localhost';
